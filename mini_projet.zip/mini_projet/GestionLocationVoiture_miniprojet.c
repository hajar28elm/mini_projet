#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//les structures du projet:

//structure voiture
typedef struct Voiture{
	int idVoiture;
	char marque[15];
	char nomVoiture[15];
	char couleur[7];
	int nbplaces;
	int prixJour;
	char EnLocation[4];
}voiture;

//structure contrat

//la structure de la date:
typedef struct date{
	int jour;
	int mois;
	int annee;
}date;
typedef struct contratLocation
{
	float numContrat;
	int idVoiture;
	int idClient;
	date debut;
	date fin;
	int cout;
}contrat;

//structure client

typedef struct Client{
	int idClient;
	char nom[20];
	char prenom[20];
	int cin;
	char adresse[15];
	int telephone;
}client;

//les menus

//***********la gestion de la voiture***********

//menu gestion voiture:
int MenuGestionVoiture(){
	system("cls");
	int choix;
	printf("\n                               \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf");
	printf("\n                               \xb3 Gestion voiture \xb3");
	printf("\n                               \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9");
	
	printf("\n\n");
	printf("\n               \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
	printf("\n               \xba                                              \xba");
	printf("\n               \xba    Liste des voitures....................1   \xba");
	printf("\n               \xba    Ajouter voiture.......................2   \xba");
	printf("\n               \xba    Modifier voiture......................3   \xba");
	printf("\n               \xba    Supprimer voiture.....................4   \xba");
	printf("\n               \xba    Retour................................5   \xba");
	printf("\n               \xba                                              \xba");
	printf("\n               \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
	printf("\n\n                                Votre choix  :  ");
	scanf("%d",&choix);
	return choix;
}

//lister les voitures:
void listevoiture(FILE *fichier){
	system("cls");
	voiture voi;
	char str[10];
	int position=0,taille_consol=80;
	fichier=fopen("voiture.bin","rb");  //ouvrir le fichier de la voiture en mode lecture:
	    if(fichier!=NULL){
	    	printf("                    LISTE DES VOITURES:\n\n");
	    	while(position<taille_consol){ //construire une ligne horizontale:
              fprintf(stdout, "_" );
              position++;
			  }
            printf("\n");
	 	    printf("|idVoiture|   marque     |  nomVoiture  |couleur| nbplaces| prixJour|EnLocation|\n");
	 	    position=0;
	        while(position<taille_consol){
              fprintf(stdout, "_" );
              position++;
			  }
            printf("\n");
	       while(fread(&voi,sizeof(voi),1,fichier)){  //utiliser cette methode pour afficher le contenu du fichier sous forme d'un tableau:
	        printf("|%d%*c%s%*c%s%*c%s%*c%d%*c%d%*c%s       |\n",voi.idVoiture,10-strlen(itoa(voi.idVoiture,str,10)),'|',voi.marque,15-strlen(voi.marque),'|',voi.nomVoiture,15-strlen(voi.nomVoiture),'|',voi.couleur,8-strlen(voi.couleur),'|',voi.nbplaces,10-strlen(itoa(voi.nbplaces,str,10)),'|',voi.prixJour,10-strlen(itoa(voi.prixJour,str,10)),'|',voi.EnLocation);
	         position=0;
	         while(position<taille_consol){
               fprintf(stdout, "_" );
               position++;
			   }
            printf("\n");}
            fclose(fichier);
			}
    else printf("le fichier n'existe pas \n"); //afficher ce message si le fichier n'existe pas:
}

//ajouter une voiture dans le fichier:
void ajouterv(){
	system("cls");
	voiture e;
	FILE* fichier=fopen("voiture.bin","ab"); //ouvrir le fichier voiture en mode ajout pour ajouter les voitures desirees:
	if(fichier!=NULL){
	do{                       //utiliser la boucle do...while pour controler la saisie des informations:
	   printf("idvoiture: ");
	   scanf("%d",&e.idVoiture);
    }while(e.idVoiture<0 || e.idVoiture>99999999);
	do{
	   printf("sa marque: ");
	   fflush(stdin);
	   gets(e.marque);
	}while(strlen(e.marque)>15);
	do{
	   printf("nom de voiture: ");
	   fflush(stdin);
   	   gets(e.nomVoiture);
    }while(strlen(e.nomVoiture)>15);
	do{
	   printf("sa couleur: ");
	   fflush(stdin);
	   gets(e.couleur);
    }while(strlen(e.couleur)>7);
	do{
	   printf("le nombre de places: ");
	   scanf("%d",&e.nbplaces);
    }while(e.nbplaces<0 || e.nbplaces>1000);
	do{
	   printf("prixJour: ");
	   scanf("%d",&e.prixJour);
    }while(e.prixJour<0 || e.prixJour>999999999);
	do{
	   printf("En location:(Oui/Non): ");
	   scanf("%s",e.EnLocation);
    }while(strcmp(e.EnLocation,"NON")!=0 && strcmp(e.EnLocation,"non")!=0 && strcmp(e.EnLocation,"oui")!=0 && strcmp(e.EnLocation,"OUI")!=0 );
	fwrite(&e,sizeof(e),1,fichier);  //enregestrer la voiture dans le fichier voiture
	fclose(fichier);
	printf("la voiture est ajoutee avec succes.\n"); //afficher ce message apr�s l'ajout de la voiture:
}
	else printf("le fichier n'existe pas \n"); //afficher ce message en cas d'erreur(le fichier n'existe pas)	
}
// calculer le nombre de jours pour calculer le cout:
//utiliser cette methode pour calculer le nombre de jour:
int  calculnbjour(int ann,int mo,int j){
	int nbjour,an,a,b,c,q,reste;
	an=ann-2000;     //soustraire 2000 de l'annee entree,
	q=an/4;          //obtenir le nombre des annees bissextiles
	reste=an-q;      //obtenir le nombre des annees communes
	if(ann%4==0){
	    a=q*366+reste*365;
	     c=29;   //les jours du mois f�vrier
		 }
	 else{
	 	a=q*366+reste*365;
	 	c=28;   //les jours du mois f�vrier
	 }
	if(mo==2)
	  b=31;
	   else if(mo==3)
	    b=31+c;
	     else if(mo==4)
	      	b=31*2+c;
	      	else if(mo==5)
	      	 b=31*2+c+30;
	      	  else if(mo==6)
	      	    b=31*3+c+30;
	      	     else if(mo==7)
	      	       b=31*3+c+30*2;
	      	        else if(mo==8)
	      	          b=31*4+c+30*2;
	      	            else if(mo==9)
	      	              b=31*5+c+30*2;
	      	                 else if(mo==10)
	      	                   b=31*5+c+30*3;
	      	                     else if(mo==11)
	      	                      b=31*6+c+30*3;
	      	                        else if(mo==12)
	      	                         b=31*6+c+30*4;
	    nbjour=a+b+j;   //calculer le nombre de jours total depuis 2000 jusqu'� l'annee saisie
	return nbjour;
}
//modifier les infos concernant une voiture:
void modifierVoiture(FILE *fichier){
	system("cls");
    voiture vt;
    contrat cnt;
    FILE *file=NULL,*file1=NULL;
    int choix,find=0,id,r,s,deb,fin,a=0;
    again:       //d�finir une label si l'utilisateur a saisi un id qui n'existe pas et veut le resaisi:
    do{
       printf("saisir id de la voiture que tu veux modifier:\n");
	   scanf("%d",&id);
    }while(id<0 || id>99999999);
    fichier=fopen("voiture.bin","rb");  //ouvrir le fichier des voitures
    FILE *temp=fopen("voiturecopie.bin","wb");  //ouvrir un fichier copie pour copier le contenu du fichier voiture avec les modifications etablis:
	if(fichier!=NULL){
	  rewind(fichier);
	  while(fread(&vt,sizeof(vt),1,fichier)){
		  if(vt.idVoiture==id && find==0)
		   {
			do{
			  printf("Choisir le champs que vous-voulez modifier:\n"); //afficher un menu pour l'utilisateur 
              printf("1- La marque \n");	
	          printf("2- Le nom \n");
              printf("3- La couleur\n");
              printf("4- Le nombre de places \n");	
	          printf("5- Le prix par jour \n");
              printf("6- En location\n");
              printf("7- Retour\n");
              scanf("%d",&choix);
              switch(choix)
			  {
			  	case 1:
			  	  do{
			  	     printf("Saisir la nouvelle marque : ");
			  	     fflush(stdin);
			  	     gets(vt.marque);
			      }while(strlen(vt.marque)>15);
			  	    printf("modifier un champs de voiture____________1.\nretourner au menu de gestion de voiture__________0.\n");
			  	    scanf("%d",&r);
			  	  if(!r) { a=1;goto terminer;} //donner un plaisir � l'utilisateur,c'est de ne pas afficher le menu une autre fois s'il ne veut pas modifier une autre chose:
			  	  break;
			  	case 2:
			  	  do{
			         printf("Saisir le nouveau nom : ");
			         fflush(stdin);
			  	     gets(vt.nomVoiture);
			      }while(strlen(vt.nomVoiture)>15);
			  	    printf("modifier un champs de voiture____________1.\nretourner au menu de gestion de voiture__________0.\n");
			  	    scanf("%d",&r);
			  	  if(!r) {a=1;
					goto terminer;}
			  	  break;
			  	case 3:
			  	  do{
			         printf("Saisir la nouvelle couleur : ");
			         fflush(stdin);
			  	     gets(vt.couleur);
			      }while(strlen(vt.couleur)>7);
			  	    printf("modifier un champs de voiture____________1.\nretourner au menu de gestion de voiture__________0.\n");
			  	    scanf("%d",&r);
			  	  if(!r) {a=1;
					      goto terminer;}
			  	  break;
				case 4:
				  do{
			         printf("Saisir le nombre de places : ");
			  	     scanf("%d",&vt.nbplaces);
			      }while(vt.nbplaces<0 || vt.nbplaces>1000);
			  	    printf("modifier un champs de voiture____________1.\nretourner au menu de gestion de voiture__________0.\n");
			  	    scanf("%d",&r);
			  	  if(!r) {
				    	a=1;
					    goto terminer;}
			  	  break;
				case 5:  //si l'utilisateur a modifi� le prix on doit modifier le cout du contrat concernant cette voiture s'il existe:
				  do{
			         printf("Saisir le nouveau prix : ");
			  	     scanf("%d",&vt.prixJour);
			      }while(vt.prixJour<0 || vt.prixJour>999999999);
			            file=fopen("contrat.bin","rb");
			             file1=fopen("contratcopie.bin","ab");
			              while(fread(&cnt,sizeof(cnt),1,file)){
			              	  if(vt.idVoiture==cnt.idVoiture){
			              	  	    deb=calculnbjour(cnt.debut.annee,cnt.debut.mois,cnt.debut.jour); //calculer le nombre de jours de la date de debut:
                                    fin=calculnbjour(cnt.fin.annee,cnt.fin.mois,cnt.fin.jour); //calculer le nombre de jours de la date de la fin:
			              	  	    cnt.cout=vt.prixJour*(fin-deb);  //calculer le cout:
			              	  	    fwrite(&cnt,sizeof(cnt),1,file1);
								}
							  else fwrite(&cnt,sizeof(cnt),1,file1);
						  }
					  fclose(file);
	                  fclose(file1);
	  	 	          remove("contrat.bin");
	  	 	          rename("contratcopie.bin","contrat.bin");
						  
			  	    printf("modifier un champs de voiture____________1.\nretourner au menu de gestion de voiture__________0.\n");
			  	    scanf("%d",&r);
			  	  if(!r) {
					      a=1;
					      goto terminer;}
			  	  break; 
			  	case 6:
			  	  do{
			         printf("En location : ");
			  	     scanf("%s",vt.EnLocation);
			      }while(strcmp(vt.EnLocation,"NON")!=0 && strcmp(vt.EnLocation,"non")!=0 && strcmp(vt.EnLocation,"oui")!=0 && strcmp(vt.EnLocation,"OUI")!=0);
			  	    printf("modifier un champs de voiture____________1.\nretourner au menu de gestion de voiture__________0.\n");
			  	    scanf("%d",&r);
			  	  if(!r) {a=1;
					      goto terminer;}
			  	  break;
			  	default : fwrite(&vt,sizeof(vt),1,temp);break;	  	
	           }
		    }while(choix>0 && choix<7);
		     terminer:
		   	 find=1;
		   	 if(a==1){
		     fwrite(&vt,sizeof(vt),1,temp);a=0;}
		   }
	       else
	  	 	 fwrite(&vt,sizeof(vt),1,temp);
		   }
	  if(!find) {
	           printf("DESOLE!!!!la voiture de id %d n'existe pas dans le fichier\n",id); //afficher ce message en cas d'erreur!!
	           do{
			     printf("voulez-vous chercher par un autre id\noui__________1.\nnon__________0.\n");
			     scanf("%d",&s);
		       }while(s!=0 && s!=1);
			   if(s) {
			          fclose(temp);
	                  fclose(fichier);
	  	 	          remove("voiture.bin");  
	  	 	          rename("voiturecopie.bin","voiture.bin");
			          goto again;
					  }
				}
	  fclose(temp);
	  fclose(fichier);
	  remove("voiture.bin"); //supprimer le fichier ancien:
	  rename("voiturecopie.bin","voiture.bin");	//renommer le fichier copie qui contient le contenu avec les modifications
}
else("le fichier n'existe pas \n");	//afficher ce message en cas d'erreur!!
}

//supprimer une voiture:
void supprimerVoiture(FILE *fichier){
	system("cls");
	voiture vt;
	int id,find=0;
    fichier=fopen("voiture.bin","rb");  //ouvrir le fichier voiture:
    FILE *temp=fopen("voiturecopie.bin","wb"); //ouvrir un fichier copie pour copier le contenu du fichier voiture sauf la voiture voulue supprimee;
    do{
       printf("saisir l'id de la voiture que vous voulez supprimer: ");
       scanf("%d",&id);
    }while(id<0 || id>99999999);
    if(fichier!=NULL){
    	while(fread(&vt,sizeof(vt),1,fichier)){
        	if(vt.idVoiture!=id)
    	    fwrite(&vt,sizeof(vt),1,temp);
			else find=1;
			}
		if(find) printf("la voiture du id %d est supprimee avec succes \n",id); //afficher ce message en cas de succes!!
		else printf("la voiture du id %d n'existe pas dans le fichier \n",id); //afficher ce message en cas d'erreur!!
	  fclose(temp);    //fermer les fichiers
	  fclose(fichier);
	  remove("voiture.bin");  //supprimer le fichier ancien
	  rename("voiturecopie.bin","voiture.bin"); //renommer le fichier copie
}
else("le fichier n'existe pas \n");	//afficher ce message en cas d'erreur!!
}

//***********la gestion des clients***********

//menu gestion client:
int MenuGestionClient(){
	system("cls");
	int choix;
	printf("\n                               \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf");
	printf("\n                               \xb3 Gestion client  \xb3");
	printf("\n                               \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9");
	
	printf("\n\n");
	printf("\n               \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
	printf("\n               \xba                                              \xba");
	printf("\n               \xba    Liste des clients.....................1   \xba");
	printf("\n               \xba    Ajouter client........................2   \xba");
	printf("\n               \xba    Modifier client.......................3   \xba");
	printf("\n               \xba    Supprimer client......................4   \xba");
	printf("\n               \xba    Retour................................5   \xba");
	printf("\n               \xba                                              \xba");
	printf("\n               \xba                                              \xba");
	printf("\n               \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
	printf("\n\n                                Votre choix  :  ");
	scanf("%d",&choix);
	return choix;
	
}

//la liste des clients:
void listeclient(FILE *fichier){
	system("cls");
	client cl;
	char str[10];
	int position=0,taille_consol=90;
	fichier=fopen("client.bin","rb"); //ouvrir le fichier client en mode lecture:
	 if(fichier!=NULL){
	    	printf("                              LISTE DES CLIENTS\n\n");
	     	while(position<taille_consol){
             fprintf(stdout, "_" );
             position++;
			 }
            printf("\n");
	        printf("|idClient |       nom         |      prenom       |   cin   |    adresse   |  telephone  |  \n");
	        position=0;
            while(position<taille_consol){
             fprintf(stdout, "_" );
             position++;
			 }
            printf("\n");
	        while(fread(&cl,sizeof(cl),1,fichier)){ //utiliser cette methode pour afficher le contenu du fichier sous forme d'un tableau
	          printf("|%d%*c%s%*c%s%*c%d%*c%s%*c%d%*c\n",cl.idClient,10-strlen(itoa(cl.idClient,str,10)),'|',cl.nom,20-strlen(cl.nom),'|',cl.prenom,20-strlen(cl.prenom),'|',cl.cin,10-strlen(itoa(cl.cin,str,10)),'|',cl.adresse,15-strlen(cl.adresse),'|',cl.telephone,14-strlen(itoa(cl.telephone,str,10)),'|');
	          position=0;
	          while(position<taille_consol){
                fprintf(stdout, "_" );
                position++;
				}
              printf("\n");
		}
     fclose(fichier);
	 }
    else printf("le fichier n'existe pas \n");//afficher ce message en cas d'erreur!!
}

//ajouter un client dans le fichier:
void ajouterc(){
	system("cls");
	client e;
	FILE* fichier=fopen("client.bin","ab"); //ouvrir le fichier client en mode ajout
	if(fichier!=NULL){
	do{          //utilise la boucle do...while pour controler la saisie des informations:
	   printf("idclient: ");
	   scanf("%d",&e.idClient);
    }while(e.idClient<0 || e.idClient>99999999);
    do{
	   printf("le nom du client: ");
	   fflush(stdin);
	   gets(e.nom);
    }while(strlen(e.nom)>20);
    do{
	   printf("le prenom du client: ");
	   fflush(stdin);
	   gets(e.prenom);
    }while(strlen(e.prenom)>20);
    do{
	   printf("CIN: ");
	   scanf("%d",&e.cin);
    }while(e.cin<0 || e.cin>99999999);
    do{
	   printf("son adresse: ");
	   fflush(stdin);
	   gets(e.adresse);
    }while(strlen(e.adresse)>15);
	do{
	   printf("numero du telephone: ");
	   scanf("%d",&e.telephone);
    }while(e.telephone<0 || e.telephone>9999999999);
	fwrite(&e,sizeof(e),1,fichier);
	fclose(fichier);
	printf("le client est ajoute avec succes\n"); //afficher ce message apr�s l'ajout du client:
	}
	else printf("le fichier n'existe pas \n");//afficher ce message en cas d'erreur!!
}

//modier les infos d'un client:
void modifierClient(FILE *fichier){
	system("cls");
    client cl;
    int id,r,s,a=0;
    int choix,find=0;
    debutClient: //d�finir une label si l'utilisateur a saisi un id qui n'existe pas et veut le resaisi:
    do{
       printf("saisir l'id du client que tu veux modifier:");
       scanf("%d",&id);
    }while(id<0 || id>99999999);
    fichier=fopen("client.bin","rb"); //ouvrir le fichier client:
    FILE *temp=fopen("clientcopie.bin","wb"); //ouvrir le fichier copie pour copier les informations avec la modification
	if(fichier!=NULL){
	  rewind(fichier);
	  while(fread(&cl,sizeof(cl),1,fichier)){
		  if(cl.idClient==id && find==0)
		   {
			do{
			  printf("Choisir le champs que vous voulez modifier:\n"); //affichier un menu a l'utilisateur
              printf("1- Le nom \n");	
	          printf("2- Le prenom \n");
              printf("3- CIN \n");
              printf("4- adresse \n");	
	          printf("5- telephone \n");
              printf("6- Retour\n");
              scanf("%d",&choix);
              switch(choix)
			  {
			  	case 1:
			  	  do{
			  	     printf("Saisir le nouveau nom : ");
			  	     fflush(stdin);
			  	     gets(cl.nom);
			      }while(strlen(cl.nom)>20);
			  	    printf("modifier un champs de client____________1.\nretourner au menu de gestion de client__________0.\n");
			  	    scanf("%d",&r);
			  	  if(!r) { a=1;
					       goto client;} //donner un plaisir � l'utilisateur,c'est de ne pas afficher le menu une autre fois s'il ne veut pas modifier une autre chose:
			  	  break;
			  	case 2:
			  	  do{
			         printf("Saisir le nouveau prenom : ");
			         fflush(stdin);
			  	     gets(cl.prenom);
			      }while(strlen(cl.prenom)>20);
			  	    printf("modifier un champs de client____________1.\nretourner au menu de gestion de client__________0.\n");
			  	    scanf("%d",&r);
			  	  if(!r) { a=1;
					       goto client;}
			  	  break;
			  	case 3:
			  	  do{
			         printf("Saisir la nouveau cin : ");
			  	     scanf("%d",&cl.cin);
			      }while(cl.cin<0 || cl.cin>99999999);
			  	    printf("modifier un champs de client____________1.\nretourner au menu de gestion de client__________0.\n");
			  	    scanf("%d",&r);
			  	  if(!r) { a=1;
					       goto client;}
			  	  break;
				case 4:
				  do{
			         printf("Saisir la nouvelle adresse : ");
			         fflush(stdin);
			  	     gets(cl.adresse);
			      }while(strlen(cl.adresse)>15);
			  	    printf("modifier un champs de client____________1.\nretourner au menu de gestion de client__________0.\n");
			  	    scanf("%d",&r);
			  	  if(!r) { a=1;
					       goto client;}
			  	  break;
				case 5:
				  do{
			         printf("Saisir le nouveau numero de telephone : ");
			  	     scanf("%d",&cl.telephone);
			      }while(cl.telephone<0 || cl.telephone>9999999999);
			  	    printf("modifier un champs de client____________1.\nretourner au menu de gestion de client__________0.\n");
			  	    scanf("%d",&r);
			  	  if(!r) { a=1;
					       goto client;}
			  	  break; 
			  	default : fwrite(&cl,sizeof(cl),1,temp); break;	  	
	        }
		}while(choix>0 && choix<6);
		   client:
		   find=1;
		   if(a==1){
		   	a=0;
		   fwrite(&cl,sizeof(cl),1,temp);}
		   }
	       else
	  	 	 fwrite(&cl,sizeof(cl),1,temp);
		   }
		if(!find) {
	           printf("le client de id %d n'existe pas dans le fichier\n",id); //afficher ce message en cas d'erreur!!
	           do{
			   printf("voulez-vous chercher par un autre id\noui__________1.\nnon__________0.\n"); //donner le choix � l'utilisateur:
			   scanf("%d",&s);
		       }while(s!=0 && s!=1);
			   if(s) {
			          fclose(temp);
	                  fclose(fichier);
	  	 	          remove("client.bin");
	  	 	          rename("clientcopie.bin","client.bin");
					  goto debutClient;}
					}
	  
	  fclose(temp);
	  fclose(fichier);
	  remove("client.bin");
	  rename("clientcopie.bin","client.bin");	
}
else("le fichier n'existe pas \n"); //afficher ce message en cas d'erreur!!
}

//supprimer un client de fichier:
void supprimerClient(FILE *fichier){
	system("cls");
	client cl;
    int id;
    int choix,find=0;
    fichier=fopen("client.bin","rb");   //ouvrir le fichier client 
    FILE *temp=fopen("clientcopie.bin","wb"); //ouvrir le fichier copie pour copier tous les client sauf le client voulu supprim�:
    do{
       printf("saisir l'id du client que tu veux supprimer:");
       scanf("%d",&id);
    }while(id<0 || id>99999999);
    if(fichier!=NULL){
    	while(fread(&cl,sizeof(cl),1,fichier)){
        	if(cl.idClient!=id)
    	    fwrite(&cl,sizeof(cl),1,temp);
			else find=1;
			}
		if(find) printf("le client du id %d est supprimee avec succes \n",id); //afficher ce message en cas de succes!!
		else printf("le client du id %d n'existe pas dans votre fichier \n",id); //afficher ce message en cas d'erreur!!
	  fclose(temp);
	  fclose(fichier);
	  remove("client.bin"); //supprimer le fichier ancien
	  rename("clientcopie.bin","client.bin"); //renommer le fichier copie
}
else("le fichier n'existe pas \n");	//afficher ce message en cas d'erreur!!
}

//menu location voiture:
int MenuLocationVoiture(){
	system("cls");
    int choix;
    printf("\n                               \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf");
	printf("\n                               \xb3 Location voiture\xb3");
	printf("\n                               \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9");
	
	printf("\n\n");
	printf("\n               \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
	printf("\n               \xba                                              \xba");
	printf("\n               \xba                                              \xba");
	printf("\n               \xba    Visualiser contrat....................1   \xba");
	printf("\n               \xba    Louer voiture.........................2   \xba");
	printf("\n               \xba    Retourner voiture.....................3   \xba");
	printf("\n               \xba    Modifier contrat......................4   \xba");
	printf("\n               \xba    Supprimer contrat.....................5   \xba");
	printf("\n               \xba    Retour................................6   \xba");
	printf("\n               \xba                                              \xba");
	printf("\n               \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
	printf("\n\n                                Votre choix  :  ");
	scanf("%d",&choix);
	return choix;
	
}
//remplir un contrat:
void remplircontrat(){
	system("cls");
	contrat cnt;
	voiture vt;
	int deb,fin,var;
	FILE* fichier=fopen("contrat.bin","ab"); //ouvrir le fichier contrat:
	FILE* file=NULL;
	if(fichier!=NULL){
	do{              //utiliser la boucle do...while pour controler la saisie:
	   printf("numContrat: ");
	   scanf("%f",&cnt.numContrat);
    }while(cnt.numContrat<0 || cnt.numContrat>99999999);
    do{
	   printf("id voiture: ");
	   scanf("%d",&cnt.idVoiture);
    }while(cnt.idVoiture<0 || cnt.idVoiture>99999999);
    do{
	   printf("id client: ");
	   scanf("%d",&cnt.idClient);
    }while(cnt.idClient<0 || cnt.idClient>99999999);
    do{
	   printf("la date de debut: (jour/mois/annee)");
	   scanf("%d",&cnt.debut.jour);
	   scanf("%d",&cnt.debut.mois);
	   scanf("%d",&cnt.debut.annee);
    }while(cnt.debut.jour<1 || cnt.debut.jour>31 || cnt.debut.mois<1 || cnt.debut.mois>12 || cnt.debut.annee<2000 || cnt.debut.annee>3000);
    do{
	   printf("la date de fin: (jour/mois/annee)");
	   scanf("%d",&cnt.fin.jour);
	   scanf("%d",&cnt.fin.mois);
	   scanf("%d",&cnt.fin.annee);
    }while(cnt.fin.jour<1 || cnt.fin.jour>31 || cnt.fin.mois<1 || cnt.fin.mois>12 || cnt.fin.annee<2000 || cnt.fin.annee>3000);
    
     deb=calculnbjour(cnt.debut.annee,cnt.debut.mois,cnt.debut.jour); //calculer le nombre des jours
     fin=calculnbjour(cnt.fin.annee,cnt.fin.mois,cnt.fin.jour);
     file=fopen("voiture.bin","rb");
        while(fread(&vt,sizeof(vt),1,file)){
            	if(vt.idVoiture==cnt.idVoiture){ //recuperer le prix par jour pour calculer le cout:
        		  var=vt.prixJour;
			     }
	     	}
    fclose(file);
    cnt.cout=(fin-deb)*var; //calculer le cout
	fwrite(&cnt,sizeof(cnt),1,fichier); //enregister le contrat dans le fichier
	fclose(fichier);
	printf("le contrat est remplit avec succees \n"); //afficher ce message en cas de succes!!
}
	else printf("le fichier n'existe pas \n");
}

//visialiser les informations contenues dans un contrat � partir de son numero:
void visualiserContrat(){ 
     system("cls");
     FILE* fichier=NULL;
     contrat cnt;
     char str[10];
     int find=0,position=0,taille_consol=90;
     float num;
     do{
        printf("saisir le numero du contrat a visualiser: ");
        scanf("%f",&num);
     }while(num<0 || num>100000);
    fichier=fopen("contrat.bin","rb"); //ouvrir le ficher contrat
    if(fichier!=NULL){
       while(fread(&cnt,sizeof(cnt),1,fichier)){
	     if(cnt.numContrat==num){  //chercher le contrat qui a le meme numero saisi:
	     printf("\n\n");
	     printf("numContrat:   idVoiture:    idClient:     dateDeb:             dateFin:            cout:\n");
	     while(position<taille_consol){
           fprintf(stdout, "_" );
           position++;
		   }
           printf("\n");
	     printf("%.0f%*c%d%*c%d%*c%d/%d/%d  %*c%d/%d/%d  %*c%d \n",cnt.numContrat,14-strlen(itoa(cnt.numContrat,str,10)),' ',cnt.idVoiture,14-strlen(itoa(cnt.idVoiture,str,10)),' ',cnt.idClient,14-strlen(itoa(cnt.idClient,str,10)),' ',cnt.debut.jour,cnt.debut.mois,cnt.debut.annee,10,' ',cnt.fin.jour,cnt.fin.mois,cnt.fin.annee,10,' ',cnt.cout);
	     find=1;
		 }
		 }
	  fclose(fichier);
	 if(!find) printf("desolee!!!! Ce contrat n'existe pas \n"); //afficher ce message en cas d'erreur!!
}
    else printf("le fichier n'existe pas \n"); //afficher ce message en cas d'erreur!! 
}

//louer une voiture:
void louervoiture(){ 
    system("cls");
    char nm[20], prnm[20],mar[15],nmv[15],col[7],NON[]="NON",OUI[]="OUI",non[]="non";
    int nbplc,prix,find=0,trouve=0,l=0,s;
    voiture v;
    client cl;
    FILE *fichier=NULL,*temp=NULL;
    do{              //controler la saisie
       printf("saisir le nom du client: \n");
       fflush(stdin);
	   gets(nm);
    }while(strlen(nm)>20);
    do{
	   printf("saisir le prenom du client: \n");
	   fflush(stdin);
	   gets(prnm);
    }while(strlen(prnm)>20);
	debutLouer:  //definir une label pour retourner ici si l'utilisateur a trouv� que la voiture desir�e n'existe pas ou elle est deja lou�e et il veut chercher une autre voiture:
	printf("saisir les informations du voiture voulue: \n");
	do{
	   printf("sa marque: ");
	   fflush(stdin);
	   gets(mar);
    }while(strlen(mar)>15);
    do{
	   printf("nom de voiture: ");
	   fflush(stdin);
	   gets(nmv);
    }while(strlen(nmv)>15);
    do{
	   printf("sa couleur: ");
	   fflush(stdin);
	   gets(col);
    }while(strlen(col)>7);
    do{
	   printf("le nombre de places: ");
	   scanf("%d",&nbplc);
    }while(nbplc<0 || nbplc>1000);
    do{
	   printf("prixJour: ");
	   scanf("%d",&prix);
    }while(prix<0 || prix>1000000000);
    fichier=fopen("voiture.bin","rb");
       if(fichier!=NULL){
	 	while(fread(&v,sizeof(v),1,fichier)){
	 		// chercher si la voiture  existe:
	 	  if(strcmp(v.marque,mar)==0 && strcmp(v.nomVoiture,nmv)==0 && strcmp(v.couleur,col)==0 && v.nbplaces==nbplc && v.prixJour==prix){
	 	  	 trouve=1;
	 	     if(strcmp(v.EnLocation,non)==0 || strcmp(v.EnLocation,NON)==0){ //si la voiture n'est pas lou�e alors elle sera lou�e
	 	     temp=fopen("voiturecopie.bin","wb");
	 	       if(temp!=NULL){
	 	       	  rewind(fichier);
	 	       	  while(fread(&v,sizeof(v),1,fichier)){
	 	       	 	if(strcmp(v.marque,mar)==0 && strcmp(v.nomVoiture,nmv)==0 && strcmp(v.couleur,col)==0 && v.nbplaces==nbplc && v.prixJour==prix){
	 	       	 	   strcpy(v.EnLocation,OUI);  //changer la valeur d'en location de non � oui:
	 	       	 	   fwrite(&v,sizeof(v),1,temp);
						}
	 	       	 	else
	 	       	 	   fwrite(&v,sizeof(v),1,temp);
					 }
	 	       	  
				}
			    fclose(temp);
	 	        fclose(fichier);
	  	        remove("voiture.bin");
	  	        rename("voiturecopie.bin","voiture.bin");
	  	        printf("la voiture est louee avec succes.Entrez les informations concernant le contrat: \n"); //la voiture est louee avec succes par l'utilisateur
	  	        printf("appuyez sur entree pour remplir le contrat\n");
	  	        getch();
	 	        remplircontrat(); //demander a l'utilisateur de remplir le contrat de location en appelant la fonction de remplissage
	 	   } 
		    else {
			   printf("cette voiture est deja louee par un autre client \n"); //si la voiture est lou�e on demande � l'utilisateur de choisir
		       do{
			   printf("voulez-vous chercher une autre voiture si elle est disponible\noui__________1.\nnon__________0.\n");
			   scanf("%d",&s);
		       }while(s!=0 && s!=1);
		       l=1;
			   if(s) {
			          trouve=0;
					  l=0;
	 	              fclose(fichier);
	  	              goto debutLouer;}
					}	    
	 }
	        
   }  fclose(fichier);
   }
        else printf("le fichier n'existe pas\n"); //afficher ce message en cas d'erreur!!
        if(!trouve){
		printf("desole!!!! cette voiture n'existe pas dans le fichier \n"); //afficher ce message en cas d'erreur!! et on demande � l'utilisateur de choisir:
		       do{
			   printf("voulez-vous chercher une autre voiture chez nous\noui__________1.\nnon__________0.\n");
			   scanf("%d",&s);
		       }while(s!=0 && s!=1);
			   if(s) { trouve=0;
			           l=0;
	 	              fclose(fichier);
					  goto debutLouer;}
					}
		else if(trouve && l==0){   //si on trouv� la voiture et elle est lou�e avec succes par l'utilisateur on fait le traitement suivant
	    fichier=fopen("client.bin","rb");
	        if(fichier!=NULL){
	 	       while(fread(&cl,sizeof(cl),1,fichier)){
	 		      if(strcmp(nm,cl.nom)==0 && strcmp(prnm,cl.prenom)==0){  
	 		    	printf("ce client est deja enregestre dans le fichier \n"); //afficher ce message si l'utilisateur est d�ja engregestr� dans le fichier client:
	 		 	    find=1;
					}
			}
		fclose(fichier);
	 	if(!find){
	 		printf("ce client n'existe pas dans le fichier: \n"); //si le client n'existe pas on lui demande de saisir ses infos 
	 		printf("saisir votre information s'il vous plait: \n");
	 		printf("appuyez sur entree pour ajouter les informations\n");
	 		getch();
	 		ajouterc(); //on ajoute le client au fichier client:
		 }
}
}
}

//modifier contrat:
void modifierContrat(){
	system("cls");
	FILE *fichier=NULL,*file=NULL;
    contrat cnt;
    voiture vt;
    float num;
    int choix,find=0,r,s,var,deb,fin;
    debutContrat: //d�finir une label si l'utilisateur a saisi un num qui n'existe pas et veut le resaisi:
    fichier=fopen("contrat.bin","rb");
    FILE *temp=fopen("contratcopie.bin","wb");
    do{
    printf("saisir le numero du contrat que tu veux modifier:");
    scanf("%f",&num);
    }while(cnt.numContrat<0 || cnt.numContrat>99999999);
	if(fichier!=NULL){
	  rewind(fichier);
	  while(fread(&cnt,sizeof(cnt),1,fichier)){
		  if(cnt.numContrat==num && find==0)
		   { 
			do{
			  printf("Choisir le champs que vous voulez modifier:\n");	
	          printf("1- date debut \n");
              printf("2- date fin \n");	
              printf("3- Retour\n");
              scanf("%d",&choix);
              switch(choix)
			  {
			  	 case 1:
			  	  do{
			         printf("Saisir la nouveau date de debut(jour/mois/annee) : ");
			  	     scanf("%d",&cnt.debut.jour);
			  	     scanf("%d",&cnt.debut.mois);
			  	     scanf("%d",&cnt.debut.annee);
			      }while(cnt.debut.jour<1 || cnt.debut.jour>31 || cnt.debut.mois<1 || cnt.debut.mois>12 || cnt.debut.annee<2000 || cnt.debut.annee>3000);
			  	  break;
			  	case 2:
			  	  do{
			         printf("Saisir la nouveau date de la fin(jour/mois/annee) : ");
			  	     scanf("%d",&cnt.fin.jour);
			  	     scanf("%d",&cnt.fin.mois);
			  	     scanf("%d",&cnt.fin.annee);
			      }while(cnt.fin.jour<1 || cnt.fin.jour>31 || cnt.fin.mois<1 || cnt.fin.mois>12 || cnt.fin.annee<2000 || cnt.fin.annee>3000);
			  	  break;
			  	default : deb=calculnbjour(cnt.debut.annee,cnt.debut.mois,cnt.debut.jour); //si la date de debut ou de la fin est chang�e on doit changer le cout
			  	          fin=calculnbjour(cnt.fin.annee,cnt.fin.mois,cnt.fin.jour);
			  		    file=fopen("voiture.bin","rb");
                         while(fread(&vt,sizeof(vt),1,file)){
                        	if(vt.idVoiture==cnt.idVoiture){
        		             var=vt.prixJour; //on recup�re le prix par jour pour modifier le cout
			                 }
	     	              }
                    fclose(file);
                    cnt.cout=(fin-deb)*var;
				   fwrite(&cnt,sizeof(cnt),1,temp); break;	  	
	    }
		}while(choix>0 && choix<3);
		 find=1;
		 }
	       else
	  	 	 fwrite(&cnt,sizeof(cnt),1,temp);
		   }
	  if(!find) {
	           printf("le contrat du numero %.0f n'existe pas dans le fichier\n",num); //afficher ce message en cas d'erreur!!
	           do{
			   printf("voulez-vous chercher par un autre numero\noui__________1.\nnon__________0.\n");
			   scanf("%d",&s);
		       }while(s!=0 && s!=1);
			   if(s){ fclose(temp);
	                  fclose(fichier);
	  	 	          remove("contrat.bin");
	  	 	          rename("contratcopie.bin","contrat.bin");
			          goto debutContrat;}
					}
	  fclose(temp);
	  fclose(fichier);
	  remove("contrat.bin");
	  rename("contratcopie.bin","contrat.bin");	
}
else("le fichier n'existe pas \n"); //afficher ce message en cas d'erreur!!
}

//supprimer un contrat 6:
void supprimerContrat(FILE *fichier){
	system("cls");
	voiture vt;
	contrat cnt;
    int id;
    int find=0,trouve=0;
    FILE *fichier1=NULL,*temp1=NULL;
    fichier=fopen("voiture.bin","rb");
    FILE *temp=fopen("voiturecopie.bin","wb");
    do{
    printf("saisir le id de la voiture du contrat que tu veux supprimer:"); //on demande � l'utilisateur de saisir l'id de la voiture du contrat
    scanf("%d",&id);
    }while(cnt.idVoiture<0 || cnt.idVoiture>99999999);
    if(fichier!=NULL){
    	while(fread(&vt,sizeof(vt),1,fichier)){
        	if(vt.idVoiture!=id)
    	    fwrite(&vt,sizeof(vt),1,temp);
			else{
			     trouve=1; 
			   if(strcmp(vt.EnLocation,"OUI")==0 || strcmp(vt.EnLocation,"oui")==0){ //si la voiture existe et elle est en location on change la valeur de oui a non
			   	  strcpy(vt.EnLocation,"NON");
			   	   fwrite(&vt,sizeof(vt),1,temp);
			   	   fichier1=fopen("contrat.bin","rb");
                   temp1=fopen("contratcopie.bin","wb");
                   while(fread(&cnt,sizeof(cnt),1,fichier1)){ //on supprime le contrat qui a le meme id de la voiture saisie
                   	   if(cnt.idVoiture!=id)
    	               fwrite(&cnt,sizeof(cnt),1,temp1);
    	               else find=1;
					   }
			   fclose(temp1);
	           fclose(fichier1);
	  	 	   remove("contrat.bin");
	  	 	   rename("contratcopie.bin","contrat.bin");
			} else {
			        fwrite(&vt,sizeof(vt),1,temp); 
			        //afficher ce message si la voiture n'est pas en location
			        printf("la voiture n'est pas en location/le contrat n'existe pas\n");
					}
				}
			}
		if(find) printf("le contrat de la voiture du id %d est supprimee avec succes \n",id); //afficher ce message en cas de succes!!
		if(!trouve) printf("la voiture de ce id n'existe pas dans le fichier\n"); //afficher ce message en cas d'erreur!!
	  fclose(temp);
	  fclose(fichier);
	  remove("voiture.bin");
	  rename("voiturecopie.bin","voiture.bin");
}
else("le fichier n'existe pas \n"); //afficher ce message en cas d'erreur!!
}

//supprimer un contrat si la voiture est retournee:
void supprimerC(int id){
	system("cls");
	FILE *fichier=NULL;
	contrat cnt;
    int find=0;
    fichier=fopen("contrat.bin","rb");
    FILE *temp=fopen("contratcopie.bin","wb");
    if(fichier!=NULL){
    	while(fread(&cnt,sizeof(cnt),1,fichier)){
        	if(cnt.idVoiture!=id)
    	    fwrite(&cnt,sizeof(cnt),1,temp);
			else find=1;
		}
		if(find) printf("le contrat de la voiture de id %d est supprimee avec succes \n",id); //afficher ce message en cas de succes!!
	  fclose(temp);
	  fclose(fichier);
	  remove("contrat.bin");
	  rename("contratcopie.bin","contrat.bin");
}else("le fichier n'existe pas \n");
}

//retourner une voiture:
void retournerVoiture(FILE *fichier){
	system("cls");
	voiture vt;
    int id,find=0,trouve=0;
    char non[]="NON";
    do{
      printf("saisir l'id du voiture que tu veux retourner: ");
      scanf("%d",&id);
    }while(id<0 || id>99999999);
    fichier=fopen("voiture.bin","rb");
    FILE *temp=fopen("voiturecopie.bin","wb");
	if(fichier!=NULL){
	  rewind(fichier);
	    while(fread(&vt,sizeof(vt),1,fichier)){
	    	if(vt.idVoiture==id && find==0){ //chercher la voiture du id saisi
	    		find=1;
	    		if(strcmp(vt.EnLocation,"OUI")==0 || strcmp(vt.EnLocation,"oui")==0){ //si elle en location en change la valeur d'en location de oui a non puis on supprime le contrat
	    		trouve=1;
	    		strcpy(vt.EnLocation,non);
	    		fwrite(&vt,sizeof(vt),1,temp);
	    		supprimerC(vt.idVoiture);
				}
	    		else { 
				       fwrite(&vt,sizeof(vt),1,temp);
	    		       printf("cette voiture est deja retournee \n"); //afficher ce message si la voiture est deja retouener avant:
				}
			}
			else
			  fwrite(&vt,sizeof(vt),1,temp);	
		}
		if(!find) printf("la voiture de id %d n'existe pas dans le fichier \n",id);//afficher ce message en cas d'erreur!!
		if(trouve) printf("voiture retournee avec succes \n");//afficher ce message en cas de succes!!
		fclose(temp);
	    fclose(fichier);
	  	remove("voiture.bin");
	    rename("voiturecopie.bin","voiture.bin");
}
}

//menu principale:
int MenuPrincipal(){
	system("cls");
	int choix;
	printf("\n                               \xda\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xbf");
	printf("\n                               \xb3 Menu Principale \xb3");
	printf("\n                               \xc0\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xc4\xd9");
	
	printf("\n\n");
	printf("\n               \xc9\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbb");
	printf("\n               \xba                                              \xba");
    printf("\n               \xba    LOCATION..............................1   \xba");
	printf("\n               \xba    GESTION VOITURE.......................2   \xba");
	printf("\n               \xba    GESTION CLIENTS.......................3   \xba");
    printf("\n               \xba    QUITTER...............................4   \xba");
    printf("\n               \xba                                              \xba");
	printf("\n               \xc8\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xbc");
	printf("\n\n                                Votre choix  :  ");
	scanf("%d",&choix);
	return choix;
}
//le main:
int main(int argc,char* argv[]){
	int a,b,c,d;
	FILE* fichier=NULL;
	do{
		a=MenuPrincipal();
		switch(a){
			case 1: do{
				       b=MenuLocationVoiture();
					   switch(b){
					   	case 1: visualiserContrat(fichier);system("pause"); break;
					   	case 2: louervoiture();system("pause"); break;
					   	case 3: retournerVoiture(fichier);system("pause");break;
					   	case 4: modifierContrat(); break;
					   	case 5: supprimerContrat(fichier);system("pause"); break;
					   	case 6: break;
					   	default: printf("choix irrone,choisir a nouveau(entre 1 et 6)\n"); getch(); break;
					    }
					   }while(b!=6);
					   break;
			case 2: do{
				       c=MenuGestionVoiture();
					   switch(c){
					   	case 1: listevoiture(fichier); system("pause");
							    break;
						case 2: ajouterv(); system("pause");break;
						case 3: modifierVoiture(fichier); break;
						case 4: supprimerVoiture(fichier);system("pause");break;
						case 5: break;
						default: printf("choix irrone,choisir a nouveau(entre 1 et 5)\n"); getch(); break;
						         
						}
					   }while(c!=5);
					   break;
			case 3: do{
				       d=MenuGestionClient();
					   switch(d){
					   	case 1:  listeclient(fichier);system("pause");
							      break;
					   	case 2: ajouterc();system("pause"); break;
						case 3: modifierClient(fichier); break;
						case 4: supprimerClient(fichier);system("pause"); break;
						case 5: break;
						default: printf("choix irrone,choisir a nouveau(entre 1 et 5)\n");
						         getch();
								 break;
						 }
					   }while(d!=5);
					   break;
			case 4: printf("MERCI D'AVOIR UTILISER NOTRE SERVICE\n"); sleep(3);exit(1);
			default: printf("choix irrone,choisir a nouveau(entre 1 et 4)\n");
				     getch();
					 break;
		}
	}while(a!=4);
}
